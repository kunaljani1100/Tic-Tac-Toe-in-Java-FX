package sample;

import javafx.fxml.FXML;
import javafx.scene.control.Button;

public class Controller {
    int k=0;
    @FXML
    Button a,b,c,d,e,f,g,h,i;
    public void clicked1(){
        if(k%2==0){
            a.setText("X");
            k++;
        }
        else{
            a.setText("O");
            k++;
        }
    }
    public void clicked2(){
        if(k%2==0){
            b.setText("X");
            k++;
        }
        else{
            b.setText("O");
            k++;
        }
    }
    public void clicked3(){
        if(k%2==0){
            c.setText("X");
            k++;
        }
        else{
            c.setText("O");
            k++;
        }
    }
    public void clicked4(){
        if(k%2==0){
            d.setText("X");
            k++;
        }
        else{
            d.setText("O");
            k++;
        }
    }
    public void clicked5(){
        if(k%2==0){
            e.setText("X");
            k++;
        }
        else{
            e.setText("O");
            k++;
        }
    }
    public void clicked6(){
        if(k%2==0){
            f.setText("X");
            k++;
        }
        else{
            f.setText("O");
            k++;
        }
    }
    public void clicked7(){
        if(k%2==0){
            g.setText("X");
            k++;
        }
        else{
            g.setText("O");
            k++;
        }
    }
    public void clicked8(){
        if(k%2==0){
            h.setText("X");
            k++;
        }
        else{
            h.setText("O");
            k++;
        }
    }
    public void clicked9(){
        if(k%2==0){
            i.setText("X");
            k++;
        }
        else{
            i.setText("O");
            k++;
        }
    }
}
